# -*- coding: utf-8 -*-

def celsius_to_fahrenheit(c):
    return (c * 9/5) + 32

def celsius_to_kelvin(c):
    return c + 273.15

def fahrenheit_to_celsius(f):
    return (f - 32) * 5/9

def fahrenheit_to_kelvin(f):
    return (f - 32) * 5/9 + 273.15

def kelvin_to_celsius(k):
    return k - 273.15

def kelvin_to_fahrenheit(k):
    return (k - 273.15) * 9/5 + 32

def convert_temperature(value, input_scale, output_scale):
    if input_scale == 'c':
        if output_scale == 'f':
            return celsius_to_fahrenheit(value)
        elif output_scale == 'k':
            return celsius_to_kelvin(value)
        else:
            return value  # Celsius to Celsius
    elif input_scale == 'f':
        if output_scale == 'c':
            return fahrenheit_to_celsius(value)
        elif output_scale == 'k':
            return fahrenheit_to_kelvin(value)
        else:
            return value  # Fahrenheit to Fahrenheit
    elif input_scale == 'k':
        if output_scale == 'c':
            return kelvin_to_celsius(value)
        elif output_scale == 'f':
            return kelvin_to_fahrenheit(value)
        else:
            return value  # Kelvin to Kelvin
    else:
        raise ValueError("Invalid input scale. Use 'c' for Celsius, 'f' for Fahrenheit, 'k' for Kelvin.")

def main():
    # دریافت داده
    try:
        value = float(input("Enter the temperature value: "))
        input_scale = input("Enter the input scale (c for Celsius, f for Fahrenheit, k for Kelvin): ").strip().lower()
        output_scale = input("Enter the output scale (c for Celsius, f for Fahrenheit, k for Kelvin): ").strip().lower()

        # محاسبه
        result = convert_temperature(value, input_scale, output_scale)

        # چاپ
        print(f"{value} {input_scale.upper()} is equal to {result:.2f} {output_scale.upper()}")
    except ValueError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
