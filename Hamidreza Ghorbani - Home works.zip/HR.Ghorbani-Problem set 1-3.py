# -*- coding: utf-8 -*-

def main():
    numbers = []
    
    print("Please enter 20 integer numbers:")
    
    # دریافت 20 عدد صحیح
    while len(numbers) < 20:
        try:
            number = int(input(f"Enter number {len(numbers) + 1}: "))
            numbers.append(number)
        except ValueError:
            print("Invalid input. Please enter an integer.")

    # شمارش اعداد زوج
    even_count = sum(1 for number in numbers if number % 2 == 0)

    # چاپ
    print(f"Numbers entered: {numbers}")
    print(f"Number of even numbers: {even_count}")

if __name__ == "__main__":
    main()

