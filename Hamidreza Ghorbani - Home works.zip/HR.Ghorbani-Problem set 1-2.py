# -*- coding: utf-8 -*-


def factorial(n):
    if n == 0:
        return 1
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

def print_factorial_details(n):
    if n == 0:
        print(f"{n}! = 1")
        return
    calculation = " * ".join(str(i) for i in range(1, n + 1))
    result = factorial(n)
    print(f"{n}! = {calculation} = {result}")

def main():
    numbers = []
    print("Please enter 10 integer numbers:")

    while len(numbers) < 10:
        try:
            number = int(input(f"Enter number {len(numbers) + 1}: "))
            if number < 0:
                print("Please enter a non-negative integer.")
            else:
                numbers.append(number)
        except ValueError:
            print("Invalid input. Please enter an integer.")

    print("\nFactorials and their calculation methods:")
    for number in numbers:
        print_factorial_details(number)

if __name__ == "__main__":
    main()
