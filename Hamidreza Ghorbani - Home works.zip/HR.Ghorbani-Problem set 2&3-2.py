# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# بارگیری داده
data = fetch_california_housing()
X = pd.DataFrame(data.data, columns=data.feature_names)
y = pd.Series(data.target, name='AveRooms')

#تقسیم داده
X_train, X_test, y_train, y_test = train_test_split(X, y,test_size=0.2, random_state=42)

#استاندارد کردن
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ایجاد چند جمله‌ای
poly = PolynomialFeatures(degree=2)
X_train_poly = poly.fit_transform(X_train_scaled)
X_test_poly = poly.transform(X_test_scaled)

# ایجاد و آموزش مدل
model = LinearRegression()
model.fit(X_train_poly, y_train)

# محاسبه
y_pred = model.predict(X_test_poly)

 #ارزیابی
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

#چاپ
print(f"Mean Squared Error (MSE): {mse:.2f}")
print(f"R2 Score: {r2:.2f}")

plt.figure(figsize=(10,6))
plt.scatter(y_test, y_pred, color='blue')
plt.plot([y_test.min(), y_test.max()],[y_test.min(), y_test.max()], color = 'red' )
plt.xlabel('مقدار واقعی')
plt.ylabel('مقدار پیش‌بینی')
plt.show()
