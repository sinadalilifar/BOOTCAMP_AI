# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, LSTM, Dense
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# Step 2: Load the dataset from the internet
url = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/airline-passengers.csv"
data = pd.read_csv(url)

# Display the first few rows of the dataset
print("Dataset Preview:")
print(data.head())

# Step 3: Preprocess the data
data = data['Passengers'].values.astype(float)
data = data.reshape(-1, 1)

# MinMax
scaler = MinMaxScaler(feature_range=(0,1))
scaled_data = scaler.fit_transform(data)

# Create sequences 
def create_sequences(data, sequence_length=1):
    X = []
    y = []
    for i in range(len(data) - sequence_length-1):
        X.append(data[i:i+sequence_length])
        y.append(data[i+sequence_length])
    return np.array(X), np.array(y)

# Create sequences with a sequence length of 14
sequence_length = 14
X, y = create_sequences(scaled_data, sequence_length)

# Reshape X for LSTM (samples, time steps, features)
X = X.reshape(X.shape[0], 1, X.shape[1])

# Train-test split
split_ratio = 0.7
split_index = int(len(X) * split_ratio)
X_train, X_test = X[0:split_index], X[split_index:]
y_train, y_test = y[0:split_index], y[split_index:]

# Step 4: Build the LSTM Model
model = Sequential()
model.add(LSTM(8, input_shape=(1, sequence_length)))

model.add(Dense(8))
model.add(Dense(1))
model.summary()

# Compile the model with mean squared error loss and Adam optimizer
model.compile(optimizer='adam', loss='mean_squared_error')


# Train the model
history = model.fit(X_train, y_train, epochs=150, batch_size=1, verbose=1)
 
#Plot Loss
plt.plot(history.history['loss'], label='loss')
plt.ylim([0, 0.01])
plt.xlabel('Epoch')
plt.ylabel('Error [passangers]')
plt.legend()
plt.grid(True)

# Make Predictions for both Train and Test Sets
train_predictions = model.predict(X_train)
test_predictions = model.predict(X_test)

# Inverse transform the predictions and actual values to the original scale
train_predictions = scaler.inverse_transform(train_predictions)
test_predictions = scaler.inverse_transform(test_predictions)
actual_train = scaler.inverse_transform(y_train)
actual_test = scaler.inverse_transform(y_test)

# Calculate the MSR, RMSE, R2 for both Train and Test Sets
r2_train = r2_score(actual_train, train_predictions)
r2_test = r2_score(actual_test, test_predictions)

mse_train = mean_squared_error(actual_train, train_predictions)
mse_test = mean_squared_error(actual_test, test_predictions)

RMSE_train = np.sqrt(mean_squared_error(actual_train, train_predictions))
RMSE_test = np.sqrt(mean_squared_error(actual_test, test_predictions))


print(f"Train Mean Squared Error (MSE): {mse_train : .2f}")
print(f"Test Mean Squared Error (MSE): {mse_test : .2f}")

print(f"Train RMSE: {RMSE_train : .2f}")
print(f"Test RMSE: {RMSE_test : .2f}")

print(f"Train R2_score: {r2_train * 100 : .2f}")
print(f"Test R2_score: {r2_test * 100 : .2f}")

# Plot Actual vs Predicted Values
plt.figure(figsize=(14, 7))

# Plot the training data predictions
plt.plot(np.arange(len(train_predictions)), actual_train, color='blue', label='Actual Train')
plt.plot(np.arange(len(train_predictions)), train_predictions, color='cyan', linestyle='dashed', label='Predicted Train')

# Plot the testing data predictions
plt.plot(np.arange(len(train_predictions), len(train_predictions) + len(test_predictions)), actual_test, color='green', label='Actual Test')
plt.plot(np.arange(len(train_predictions), len(train_predictions) + len(test_predictions)), test_predictions, color='orange', linestyle='dashed', label='Predicted Test')

plt.title(f"Actual vs Predicted")
plt.xlabel('Time Step')
plt.ylabel('Passengers')
plt.legend()
plt.show()

# Display the first 5 predictions and actual values for the test data
print("First 5 Actual Test Values:")
print(actual_test[:5])

print("First 5 Predicted Test Values:")
print(test_predictions[:5])





