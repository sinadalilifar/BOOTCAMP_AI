def main():
    # دریافت تعداد عدد مورد نظر کاربر
    try:
        count = int(input("Enter the number of values you want to input: "))
        if count <= 0:
            raise ValueError("The number must be greater than 0.")
    except ValueError as e:
        print(f"Invalid input: {e}")
        return

    numbers = []

    # دریافت اعداد
    for i in range(count):
        while True:
            try:
                number = float(input(f"Enter number {i + 1}: "))
                numbers.append(number)
                break
            except ValueError:
                print("Invalid input. Please enter a valid number.")

    # محاسبه 
    max_number = max(numbers)
    min_number = min(numbers)
    avg_number = sum(numbers) / len(numbers)

    # Print the results
    print(f"Numbers entered: {numbers}")
    print(f"Maximum: {max_number}")
    print(f"Minimum: {min_number}")
    print(f"Average: {avg_number:.2f}")

if __name__ == "__main__":
    main()

